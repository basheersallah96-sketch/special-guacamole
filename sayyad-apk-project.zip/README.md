# صيّاد الأصوات

لعبة تدريب على النطق (28 صوت، أول/وسط/آخر الكلمة، تشجيع صوتي).

## بناء الـ APK على GitHub
1. ارفع كل محتويات هذا المجلد على Repository جديد (فرع main).
   - مجلد `.github` مخفي: إذا ما انرفع بالسحب، اعمل Add file > Create new file واكتب
     `.github/workflows/build-apk.yml` والصق محتوى الملف.
2. روح تبويب **Actions** > **Build APK** > **Run workflow**.
3. بعد 5-10 دقائق افتح التشغيلة، ونزّل **sayyad-alaswat-apk** من Artifacts (ملف zip فيه app-debug.apk).
4. ثبّته على الموبايل (اسمح بالتثبيت من مصدر غير معروف).

## نشره كموقع (اختياري)
انسخ محتويات مجلد `www` لمستودع ثاني (أو للجذر) وفعّل Settings > Pages > Branch: main.

## تعديل اللعبة
عدّل `www/index.html` وارفعه، والـ APK بينبني من جديد تلقائياً.
