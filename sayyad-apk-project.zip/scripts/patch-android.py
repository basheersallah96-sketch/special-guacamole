# يضيف إذن المايك وإعدادات خدمة التعرف على الصوت لملف AndroidManifest
p = 'android/app/src/main/AndroidManifest.xml'
s = open(p, encoding='utf-8').read()
add = ''
if 'RECORD_AUDIO' not in s:
    add += '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n'
if 'RecognitionService' not in s:
    add += ('    <queries>\n        <intent>\n'
            '            <action android:name="android.speech.RecognitionService" />\n'
            '        </intent>\n        <intent>\n'
            '            <action android:name="android.intent.action.TTS_SERVICE" />\n'
            '        </intent>\n    </queries>\n')
s = s.replace('</manifest>', add + '</manifest>')
open(p, 'w', encoding='utf-8').write(s)
print('patched')
